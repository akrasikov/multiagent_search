package jade.content.abs;

public class AbsConceptSlotFunction extends AbsConcept {
	public AbsConceptSlotFunction(String slotName) {
		super(slotName);
	}
	
    public int getAbsType() {
    	return ABS_CONCEPT_SLOT_FUNCTION;
    }
}
